export class Order {
    authorName: string;
    bookName: string;
    bookDetails: string;
    image: string;
    totalprice: number;
    orderId: number;
    orderStatus: string;
}

