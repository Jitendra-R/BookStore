import { BooksearchpipePipe } from './booksearchpipe.pipe';

describe('BooksearchpipePipe', () => {
  it('create an instance', () => {
    const pipe = new BooksearchpipePipe();
    expect(pipe).toBeTruthy();
  });
});
