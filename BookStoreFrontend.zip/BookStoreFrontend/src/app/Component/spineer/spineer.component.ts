import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spineer',
  templateUrl: './spineer.component.html',
  styleUrls: ['./spineer.component.scss']
})
export class SpineerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
